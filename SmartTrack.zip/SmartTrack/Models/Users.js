// models/Users.js

const { Sequelize, DataTypes } = require('sequelize');
const sequelize = new Sequelize('mysql://user@localhost:3306/smarttrack_db');

const Users = sequelize.define('employee', {
  EmployeeID: {
    type: DataTypes.STRING,
    autoIncrement: true,
    primaryKey: true
  },
  PasswordHash: {
    type: DataTypes.STRING,
    allowNull: false
  },
  Role: {
    type: DataTypes.STRING,
    allowNull: false,
    defaultValue: 'user'
  }
}, {
  // Other model options go here
});

module.exports = Users;
