const express = require('express');
const bcrypt = require('bcryptjs');
const { check, validationResult } = require('express-validator');
const winston = require('winston');

const Users = require('./models/Users');  // Update with your Users model path

const router = express.Router();

const loginValidation = [
    check('employeeID').isNumeric(),
    check('PasswordHash').notEmpty(),
];

router.post('/login', loginValidation, async (req, res) => {
    try {
        const errors = validationResult(req);
        if (!errors.isEmpty()) {
            winston.error('Validation error: ', errors.array());
            return res.status(422).json({ success: false, message: 'Validation error' });
        }

        const { employeeID, PasswordHash } = req.body;

        const user = await Users.findOne({ where: { employeeID: employeeID } });

        if (!user || !(await bcrypt.compare(PasswordHash, user.PasswordHash))) {
            winston.debug('Invalid credentials');
            return res.status(401).json({ success: false, message: 'Invalid credentials' });
        }

        winston.debug('Credentials Valid');
        req.session.user_id = user.EmployeeID;
        req.session.role = user.Role;
        res.json({ success: true, message: 'Login successful' });
    } catch (err) {
        winston.error('Error: ', err.message);
        res.status(500).json({ success: false, message: 'An error occurred' });
    }
});

module.exports = router;

