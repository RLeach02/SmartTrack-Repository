//Validates the data input through the Sign_In login form
function validateForm() {
    var employeeID = document.getElementById("employeeID").value;
    var password = document.getElementById("password").value;
    var employeeIDError = document.getElementById("employeeIDError");
    var passwordError = document.getElementById("passwordFeedback");

    if (employeeID === "") {
        employeeIDError.innerHTML = "Please enter your employee ID";
        return false;
    } else if (!/^\d{10}$/.test(employeeID)) {
        employeeIDError.innerHTML = "Please enter a valid employee ID number.";
        alert("Please enter a valid employee ID number.");
        return false;
    }
    else {
        employeeIDError.innerHTML = "";
    }

    if (password === "") {
        alert("Please enter your password.");
        passwordError.innerHTML = "Password is required";
        return false;
    }
    else {
        passwordError.innerHTML = "";
    }
    // If the form is valid, return the email and password
    return { email, password };
}

//Dictates the actions on user entering their login credentials
function login(event) {
    event.preventDefault(); // prevent the form from submitting
    var feedback = document.getElementById("passwordFeedback");
    const employeeID = document.getElementById('employeeID').value;
    const password = document.getElementById('password').value;
    const jsonString = JSON.stringify({ employeeID, password });
    console.log(jsonString); // Output the JSON data to the console

    //Validates form inputs by referencing 'validateForm()'
    var credentials = validateForm();
    if (credentials) {
        console.log('credentials entered');
        //if credentials pass validation, POST to server
        const csrfToken = document.querySelector('meta[name="csrf-token"]').getAttribute('content');
        fetch('/login-form', {
            method: 'POST', headers: {
                'Content-Type': 'application/json',
                'X-CSRF-TOKEN': csrfToken
            },
            body: jsonString,
        })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    //login successful
                    window.location.href = '/Scan_RFID'; // Redirect to the RFID Scanning page
                    modal.style.display = "none";
                } else {
                    //login failed
                    feedback.style.display = 'block';
                    feedback.innerHTML = "Incorrect employee ID or password";
                }
            })
            .catch((error) => {
                console.error('Error: ', error);
            });
    } else {
        alert("Please fill out all required fields");
    }
}