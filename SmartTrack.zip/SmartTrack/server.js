const express = require('express');
const app = express();
const path = require('path');

// Set EJS as templating engine 
app.set('view engine', 'ejs');

// Set the views directory
app.set('views', path.join(__dirname, 'views'));

// Set the public directory for static files
app.use(express.static(path.join(__dirname, 'public')));

app.get('/', (req, res) => {
  res.render('home'); // Render home.ejs
});

app.get('/Sign_In', (req, res) => {
  res.render('Sign_In');
});

app.get('/home', (req, res) => {
  res.render('Home');
});

app.get('/Sign_Up', (req, res) => {
  res.render('Sign_Up');
});

app.get('/Scan_RFID', (req, res) => {
  res.render('Scan_RFID');
});

app.get('/Inventory', (req, res) => {
  res.render('Inventory');
});

app.use(express.static("public"));

app.listen(3000, () => {
  console.log('Server is running on port 3000');
});
/**
// Route handler for RFID code submission
app.post('/RFID-Form', (req, res) => {
  const { RFIDCodeInput } = req.body;

  // Perform database query to find the inventory item based on RFID code
  // Example using a fictional database model or ORM
  InventoryItem.findOne({ RFIDCode: RFIDCodeInput })
    .then((item) => {
      if (item) {
        // Found a matching inventory item
        res.json({ success: true, item });
      } else {
        // No matching item found
        res.json({ success: false });
      }
    })
    .catch((error) => {
      console.error('Error:', error);
      res.status(500).json({ error: 'Server error' });
    });
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Server is running on http://localhost:${PORT}`);
});*/

