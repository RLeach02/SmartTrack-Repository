// LogIN pop up window functionality
function openLogin() {
  var modal = document.getElementById("myModal"); // get the modal
  modal.style.display = "block"; // display the modal
  // var span = document.getElementsByClassName("close")[0];

}

//Validates the data input through the Sign_In form
function validateSignInForm() {
    var employeeID = document.getElementById("employeeID").value;
    var password = document.getElementById("password").value;
    var employeeIDError = document.getElementById("employeeIDError");
    var passwordError = document.getElementById("passwordFeedback");

    if (employeeID === "") {
        employeeIDError.innerHTML = "Please enter your employee ID";
        return false;
    } else if (!/^\d{10}$/.test(employeeID)) {
        employeeIDError.innerHTML = "Please enter a valid employee ID number.";
        alert("Please enter a valid employee ID number.");
        return false;
    }
    else {
        employeeIDError.innerHTML = "";
    }

    if (password === "") {
        alert("Please enter your password.");
        passwordError.innerHTML = "Password is required";
        return false;
    }
    else {
        passwordError.innerHTML = "";
    }
    // If the form is valid, return the email and password
    return { email, password };
}

//validates input for the Scan_RFID form
function validateScanForm() {
    var RFIDCodeInput = document.getElementById("RFID-Code").value;
    var RFIDError = document.getElementById("RFIDError");

    if (RFIDCodeInput === "") {
        RFIDError.innerHTML = "Please enter an RFID code";
        return false;
    } else if (!/^\d{1, 24}$/.test(RFIDCodeInput)) { // Pattern for 96-bit or less numeric RFID code
        RFIDError.innerHTML = "Please enter a valid RFID Code";
        alert("Please enter a valid RFID Code");
        return false;
    } else {
        RFIDError.innerHTML = "";
    }
    //if the RFID is valid returns the RFID
    return { RFIDCodeInput };
}



//Dictates the actions on user entering their login credentials
function login(event) {
    event.preventDefault(); // prevent the form from submitting
    var feedback = document.getElementById("passwordFeedback");
    const employeeID = document.getElementById('employeeID').value;
    const password = document.getElementById('password').value;
    const jsonString = JSON.stringify({ employeeID, password });
    console.log(jsonString); // Output the JSON data to the console

    //Validates form inputs by referencing 'validateSignInForm()'
    var credentials = validateSignInForm();
    if (credentials) {
        console.log('credentials entered');
        //if credentials pass validation, POST to server
        const csrfToken = document.querySelector('meta[name="csrf-token"]').getAttribute('content');
        fetch('/login-form', {
            method: 'POST', headers: {
                'Content-Type': 'application/json',
                'X-CSRF-TOKEN': csrfToken
            },
            body: jsonString,
        })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    //login successful
                    window.location.href = '/Scan_RFID'; // Redirect to the RFID Scanning page
                    modal.style.display = "none";
                } else {
                    //login failed
                    feedback.style.display = 'block';
                    feedback.innerHTML = "Incorrect employee ID or password";
                }
            })
            .catch((error) => {
                console.error('Error: ', error);
            });
    } else {
        alert("Please fill out all required fields");
    }
}

//Dictates actions on registering
function register(event) {
    event.preventDefault();
    const form = document.querySelecter('#registerForm');
    if (form.checkValidity()) {
        const employeeID = document.getElementById("employeeID").value;
        const password = document.getElementById("password").value;

        //expression patterns for validation
        const employeeIDPattern = /^\d{10}$/;
        const passwordPattern = /^(?=.*[A-Z])(?=.*[a-z])(?=.*[\$\#\!])(?=.*\d.*\d.*\d).{8,}$/;

        //validation flags
        let isValid = true;
        let employeeIDValid = true;
        let passwordValid = true;

        //validate employee ID
        if (!employeeID.match(employeeIDPattern)) {
            employeeIDValid = false;
            isValid = false;
            document.getElementById('employeeID').classList.add('is-invalid');
            document.getElementById('employeeID').classList.remove('is-valid');
        } else {
            document.getElementById('employeeID').classList.remove('is-invalid');
            document.getElementById('employeeID').classList.add('is-valid');
        }

        //validate password
        if (!password.match(passwordPattern)) {
            passwordValid = false;
            isValid = false;
            document.getElementById('password').classList.add('is-invalid');
            document.getElementById('password').classList.remove('is-valid');
        } else {
            document.getElementById('password').classList.remove('is-invalid');
            document.getElementById('password').classList.add('is-valid');
        }

        // Show validation feedback messages
        if (!employeeIDValid) {
            document.getElementById('employeeID').nextElementSibling.style.display = 'block';
        } else {
            document.getElementById('employeeID').nextElementSibling.style.display = 'none';
        }

        if (!passwordValid) {
            document.getElementById('password').nextElementSibling.style.display = 'block';
        } else {
            document.getElementById('password').nextElementSibling.style.display = 'none';
        }

        //print the values to the console
        console.log(employeeID);
        console.log(password);
        const jsonString = JSON.stringify({ employeeID, password })
        console.log(jsonString);

        const csrfToken = document.querySelector('meta[name="csrf-token"]').getAttribute('content');
        fetch('/register-form', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-CSRF-TOKEN': csrfToken
            },
            body: jsonString
        })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    alert('User registered successfully!');
                    window.location.href = '/Sign_In'; // Redirect to the Sign In page
                } else {
                    alert('User registration failed. Please try again.');
                }
            })
            .catch(error => {
                console.error('An error occurred:', error);
            });
    } else {
        alert("Please fill all required fields")
    }
}

//Dictates actions on scanning an RFID code
function scan(event) {
    event.preventDefault();
    var feedback = document.getElementById("RFIDError");
    const RFIDCodeInput = document.getElementById('RFID-Code').value;
    const jsonString = JSON.stringify({ RFIDCodeInput });
    console.log(jsonString);

    //validates form by referencing 'validateScanForm()'
    var validated = validateScanForm();
    if (validated) {
        console.log('RFID Code entered');
        //if RFID passes validation, POST to server
        const csrfToken = document.querySelector('meta[name="csrf-token"]').getAttribute('content');
        fetch('/RFID-form', {
            method: 'POST', headers: {
                'Content-Type': 'application/json',
                'X-CSRF-TOKEN': csrfToken
            },
            body: jsonString,
        })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    //login successful
                    window.location.href = '/Product'; // Redirect to the RFID Scanning page
                    modal.style.display = "none";
                } else {
                    //login failed
                    feedback.style.display = 'block';
                    feedback.innerHTML = "RFID is not included in current inventory";
                }
            })
            .catch((error) => {
                console.error('Error: ', error);
            });
    } else {
        alert("Please input an RFID Code");
    }
}

//the following two functions open and close the forgot password card respectively
function openPopup(elementId) {
  var popup = document.getElementById(elementId);
  popup.classList.add("active-popup");
}

function closePopup(elementId) {
  var popup = document.getElementById(elementId);
  popup.classList.remove("active-popup");
}

