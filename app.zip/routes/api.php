<?php

use App\Http\Controllers\UsersController;
use App\Http\Controllers\passwordController;
use App\Http\Controllers\AuthController;
use App\Http\Controllers\UserController;
use Illuminate\Support\Facades\Route;
/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "api" middleware group. Make something great!
|
*/

// UserController Routes
Route::group(['prefix' => 'user'], function () {
    Route::get('/', [UserController::class, 'showMyinfo']);
    Route::get('/{employeeID}', [UserController::class, 'show']);
    Route::post('/', [UserController::class, 'register']);
    Route::put('/{employeeID}', [UserController::class, 'update']);
    Route::delete('/{employeeID}', [UserController::class, 'destroy']);
});

//API methods for Users Table
Route::group(['prefix' => 'users'], function () {
    Route::get('/', [UsersController::class, 'index']);
    Route::get('/{employeeID}', [UsersController::class, 'show']);
    Route::post('/', [UsersController::class, 'store']);
    Route::put('/{employeeID}', [UsersController::class, 'update']);
    Route::delete('/{employeeID}', [UsersController::class, 'destroy']);
});

