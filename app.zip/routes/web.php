<?php

namespace App\Http\Controllers;

use App\Models\employee;
use Illuminate\Support\Facades\Route;
use Symfony\Component\HttpFoundation\Request;
/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/
$user = employee::find(1);
session(['employeeID' => $user->employeeID]);

Route::get('/', function () {
    return view('home');
})->name('home');

Route::get('/Sign_In', function () {
    return view('Sign_In');
})->name('Sign_In');
Route::get('/Sign_Up', function () {
    return view('Sign_Up');
})->name('Sign_Up');
Route::get('/Scan_RFID', function() {
    return view('Scan_RFID');
})->name('Scan_RFID');
Route::get('/Product', function() {
    return view('Product');
})->name('Product');
Route::get('/Inventory', function() {
    return view('Inventory');
})->name('Inventory');

Route::post('/login-form', [AuthController::class, 'Sign_In'])->name('login-form');
Route::post('/register-Form', [UserController::class, 'Sign_Up'])->name('register-Form');
Route::post('/RFID-form', [UserController::class, 'Sign_Up'])->name('RFID-form');

Route::group(['middleware' => 'web'], function () {
    Route::post('/register-form', [UserController::class, 'Sign_Up'])->name('register-form');
});

//session management code to override innate laravel session management
Route::middleware(['auth'])->group(function () {
    Route::get('/Product', 'App\Http\Controllers\UserController@Product')->name('Product');
    Route::get('/Product', 'App\Http\Controllers\UserController@Product')->name('Product');
});
