<?php
$user = auth()->user();
?>
<!DOCTYPE html>
<html lang="english">

<head>
    <title>Records</title>

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Latest compiled JavaScript -->
    <script src="<?php echo e(asset('js/Script.js')); ?>"></script>

    <!--  CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('csss/register.css')); ?>">

    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <meta charset="utf-8" />

    <link rel="stylesheet"
        href="https://fonts.googleapis.com/css2?family=Inter:wght@100;200;300;400;500;600;700;800;900&amp;display=swap"
        data-tag="font" />

    <link rel="stylesheet" href="<?php echo e(asset('css/stylesheet.css')); ?>">


</head>

<body>

    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg fixed-top" style="background-color: #f5f7fa;">
        <div class="container-fluid">
            <a class="navbar-brand" href="<?php echo e(route('home')); ?>">
                <img src="<?php echo e(asset('assets/Images/Banner_Logo.png')); ?>" alt="BannerACTHALogo120" />
            </a>
            <h1 class="navbar-text d-none d-md-block col-sm-3"> ACT Health Archives</h1>

            <button class="navbar-toggler justify-content-end" type="button" data-bs-toggle="collapse"
                data-bs-target="#collapsibleNavbar">
                <span class="navbar-toggler-icon"></span>
            </button>

            <div class="collapse navbar-collapse" id="collapsibleNavbar">
                <ul class="navbar-nav justify-content-end">
                    <li>
                        <a id="Home" href="<?php echo e(route('home')); ?>#home" class="nav-link ">Home</a>
                    </li>
                    <li>
                        <a id="About-Us" href="<?php echo e(route('home')); ?>#About Us" class="nav-link">About Us</a>
                    </li>
                    <li>
                        <a id="Contacts" href="<?php echo e(route('home')); ?>#Contact Us" class="nav-link">Contact Us</a>
                    </li>
                    <li>
                        <a id="Dashboard" href="<?php echo e(route('dashboard')); ?>" class="nav-link">Dashboard</a>
                    </li>
                    <li>
                        <div class="nav-divider"></div>
                    </li>
                    <li class="mobile-margin-top-10">
                        <a href="<?php echo e(route('home')); ?>" class="button-primary rounded">Log Out</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <section class="content mt-1" style="margin-top: 100px;">
        <div class="col-sm-12 p-5 bg-primary text-white mx-auto">
            <h1 class="display-5"><?php echo e(session('first_name')); ?>'s Records</h1>
        </div>
        <div>
            <div class="col-sm-12 p-1 bg-primary text-white background-color:aquamarine mx-auto">
                <a href="<?php echo e(route('dashboard')); ?>">
                    <button type="button" class="btn btn-success">Back to Dashboard</button>
                </a>
            </div>
        </div>
    </section>
    <section class="Control">
        <div class="container-fluid">
            <!-- Left side of screen, i.e. Tables -->
            <div class="row">


                <!-- Documents table -->
                <div class="col-sm-6 table-responsive table-responsive-sm">
                    
                    <table class="table table-hover table-sm" id="Test" name="TestTable">
                        <thead>
                            <th class="col">
                                <p class="display-6">
                                    <?php echo e(session('first_name')); ?>'s Documents
                                </p>
                            </th>
                            <tr>
                                <!-- Table Headings -->
                                <th>
                                    Document Name
                                </th>
                                <th>
                                    Document Type
                                </th>
                                <th>
                                    Upload Date
                                </th>
                                <th>
                                    Summary
                                </th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $files; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $file): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr onclick="tableRowClick('<?php echo e($file->file_name); ?>')">
                                    <td><?php echo e($file->file_name); ?></td>
                                    <td><?php echo e($file->file_category); ?></td>
                                    <td><?php echo e($file->date); ?></td>
                                    <td>
                                        <?php if($file->file_note): ?>
                                            <?php echo e($file->file_note->file_note); ?>

                                        <?php else: ?>
                                            No file note available
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <button onclick="downloadDoc('<?php echo e($file->file_name); ?>')"
                                            class="btn btn-sm button-primary">
                                            Download
                                        </button>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



                        </tbody>
                    </table>




                </div>

                <!-- Right side of screen: Document Preview -->
                <div class="col-sm-6 m-5 p-5 mx-auto rounded text-center" style="background-color: rgb(207, 213, 211);">
                    <h1 class="display-3 mx-auto align-content-center">Document Preview</h1>
                    <iframe id="documentPreview" class="col-sm-12 p-1 mx-auto"
                        src="<?php echo e(asset('assets/Images/Background_Logo.png')); ?>" width="100%" height="500px"></iframe>
                </div>
            </div>
        </div>
    </section>
</body>

<footer>
    <section class="footer wf-section">
        <div class="container-2">
            <div class="footer-wrapper-2">
                <a href="#" class="footer-brand-2 w-inline-block"><img
                        src="<?php echo e(asset('assets/Images/Banner_Logo.png')); ?>" loading="lazy" width="227"
                        sizes="(max-width: 479px) 88vw, 227px" alt=""></a>
                <div class="footer-content-2">
                    <div id="w-node-e88afaff-ea91-c9c2-0b63-22244fe33b01-e4e7dfff" class="footer-block-2">
                        <div class="title-small-2">Company</div>
                        <a href="#" class="footer-link-2">How it works</a>
                        <a href="#" class="footer-link-2">Docs</a>
                    </div>
                    <div id="w-node-e88afaff-ea91-c9c2-0b63-22244fe33b15-e4e7dfff" class="footer-block-2">
                        <div class="title-small-2">About</div>
                        <a href="#" class="footer-link-2">Terms &amp; Conditions</a>
                        <a href="#" class="footer-link-2">Privacy policy</a>
                    </div>
                </div>
            </div>
        </div>
        <div class="footer-divider-2"></div>
        <div class="footer-copyright-center-2">Copyright © 2023 Don Le || Tristan Kelly || Ryan Leach</div>
    </section>
</footer>

</html>
<?php /**PATH C:\laragon\www\MedicalRecordingSystem-reset\MedicalRecordingSystem-reset\resources\views/records.blade.php ENDPATH**/ ?>