<!DOCTYPE html>
<html lang="english">

<head>
    <title>SmartTrack</title>
    <link rel="icon" href="<?php echo e(asset('assets/Images/Favicon-icon.png')); ?>" type="image/x-icon">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Latest compiled JavaScript -->
    <script src="<?php echo e(asset('js/Script.js')); ?>"></script>

    <!--  CSS -->
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <meta charset="utf-8" />
    <link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

</head>

<body>
    <section class="navbar">
        <nav class="navbar navbar-expand-lg fixed-top"
            style="background-color: #Ff6d00; border-bottom: 2px solid #000000;">
            <div class="container-fluid align-items-center">
                <div class="navbar-brand" style="padding: 5px;">
                    <img style="height: 75px;" src="<?php echo e(asset('assets/images/SmartThink_Logo.png')); ?>" alt="SmartThink_Logo">
                </div>
                <h1 class="navbar-text text-center">SmartTrack Inventory Management</h1>

                <button class="navbar-toggler justify-content-end" type="button" data-bs-toggle="collapse"
                    data-bs-target="#collapsibleNavbar">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse justify-content-end" id="collapsibleNavbar">
                    <ul class="navbar-nav">
                        <li class="nav-item" style="padding-right: 10px;">
                            <a href="<?php echo e(route('home')); ?>" class="button-primary rounded" style="padding: 12px 25px;
                    border: 1px solid #000;
                    background-color: #Ff6d00;;
                    transition: all 200ms ease;
                    color: #000;
                    font-size: 15px;
                    line-height: 20px;
                    letter-spacing: 2px;
                    box-shadow: 0 0 1px 1px #000;
                    text-transform: uppercase;" onmouseover="this.style.backgroundColor='#A2a2a2';"
                                onmouseout="this.style.backgroundColor='#Ff6d00';">Home</a>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>
    </section>

    <section id="Login Form">
        <!--Page Banner-->
        <div class="container-fluid" style="padding-top: 100px; background-color: #000000;">
            <div class="col-sm-12 p-5 text-black mx-auto" style="background-color: #Ff6d00;">
                <h1 class="display-3">Sign Up</h1>
                <h1 class="display-6">Sign Up to enjoy our services.</h1>
            </div>
        </div>

        <!--Register Form-->
        <div class="row p-5" style="background-color: #000000;">
            <!--Column to Hold Login Form-->
            <div class="col-sm-4 p-5 rounded m-5 justify-content-center mx-auto" style="background-color: #A2a2a2;">
                <form id="registerForm" class="was-validated" method="POST"  action="<?php echo e(route('register-Form')); ?>" style="padding-bottom: 10px;">
                   <?php echo csrf_field(); ?>
                    <div class="form-group col-sm-8 mb-3 mt-3">
                        <label for="employeeID" class="form-label">Employee ID:</label>
                        <input type="employeeID" class="form-control" id="employeeID" placeholder="Enter Employee ID" name="employeeID"
                            required>
                        <div id="employeeIDError" class="invalid-feedback">Please register your employee ID.</div>
                    </div>
                    <div class="form-group col-sm-8 mb-3">
                        <label for="password" class="form-label">Password:</label>
                        <input type="password" class="form-control" id="password" placeholder="Enter Password" name="password"
                            required>
                        <div id="passwordFeedback" class="invalid-feedback">Please enter a password.</div>
                    </div>
                    <div class="form-group col-sm-8 mb-3">
                        <label for="pwd" class="form-label">Confirm Password:</label>
                        <input type="password" class="form-control" id="confirm_password" placeholder="Confirm password"
                            name="confirm_password" required oninput="validateForm()">
                        <div id="passwordFeedback" class="invalid-feedback">Passwords are not matching.</div>
                    </div>
                    <button onclick="register(event)" id="loginBtn" class="btn btn-success" type="submit" style="padding: 12px 25px;
                    border: 1px solid #000;
                    background-color: #Ff6d00;;
                    transition: all 200ms ease;
                    color: #000;
                    font-size: 15px;
                    line-height: 20px;
                    letter-spacing: 2px;
                    box-shadow: 0 0 1px 1px #000;
                    text-transform: uppercase;" onmouseover="this.style.backgroundColor='#A2a2a2';"
                        onmouseout="this.style.backgroundColor='#Ff6d00';">Submit</button>
                </form>
                <!-- Link/button to login page -->
                <a href="<?php echo e(route('Sign_In')); ?>" class="btn btn-primary" style="padding: 12px 25px;
                 border: 1px solid #000;
                 background-color: #Ff6d00;;
                 transition: all 200ms ease;
                 color: #000;
                 font-size: 15px;
                 line-height: 20px;
                 letter-spacing: 2px;
                 box-shadow: 0 0 1px 1px #000;
                 text-transform: uppercase;" onmouseover="this.style.backgroundColor='#A2a2a2';"
                    onmouseout="this.style.backgroundColor='#Ff6d00';">Already have an Account?</a>
            </div>
            <!--Image on Right Side-->
            <div class="col-sm-6">
                <img class="img-fluid" src="<?php echo e(asset('assets/images/padlock.png')); ?>" alt="Padlock" />
            </div>
        </div>

        <!--Temporary Navigation Aid-->
    </section>

    <section class="footer" style="background-color: #Ff6d00;">
        <div class="container-2">
            <div class="footer-wrapper-2">
                <div class="footer-content-2 justify-content-center">
                    <div class="footer-block-2">
                        <div class="title-small-2">Company</div>
                        <a href="#" class="footer-link-2">How it works</a>
                        <a href="#" class="footer-link-2">Docs</a>
                    </div>
                    <div class="footer-block-2">
                        <div class="title-small-2">About</div>
                        <a href="#" class="footer-link-2">Terms &amp; Conditions</a>
                        <a href="#" class="footer-link-2">Privacy policy</a>
                    </div>
                </div>
            </div>
        </div>
        <div class="footer-divider-2"></div>
        <div class="footer-copyright-center-2">Copyright © 2023 Andrew Still || Ryan Leach</div>
    </section>
</body>
<?php /**PATH C:\laragon\www\SmartTrack - Reset\SmartTrack - Reset\resources\views/Sign_Up.blade.php ENDPATH**/ ?>