<!DOCTYPE html>
<html lang="english">

<head>
    <title>SmartTrack</title>
    <link rel="icon" href="<?php echo e(asset('assets/Images/Favicon-icon.png')); ?>" type="image/x-icon">

   <!-- Bootstrap CSS -->
   <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Latest compiled JavaScript -->
    <script src="<?php echo e(asset('js/Script.js')); ?>"></script>

    <!--  CSS -->
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <meta charset="utf-8" />
    <link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

</head>

<body>
    <section class="navbar">
        <nav class="navbar navbar-expand-lg fixed-top" style="background-color: #Ff6d00;">
            <div class="container-fluid align-items-center">
                <div class="navbar-brand" style="padding: 5px;">
                    <img style="height: 75px;" src="<?php echo e(asset('assets/Images/SmartThink_Logo.png')); ?>" alt="SmartThink_Logo">
                </div>
                <h1 class="navbar-text text-center">SmartTrack Inventory Management</h1>

                <button class="navbar-toggler justify-content-end" type="button" data-bs-toggle="collapse"
                    data-bs-target="#collapsibleNavbar">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse justify-content-end" id="collapsibleNavbar">
                    <ul class="navbar-nav">
                        <li class="nav-item" style="padding-right: 10px;">
                            <a href="<?php echo e(route('Sign_In')); ?>" class="button-primary rounded" style="padding: 12px 25px;
                    border: 1px solid #000;
                    background-color: #Ff6d00;;
                    transition: all 200ms ease;
                    color: #000;
                    font-size: 15px;
                    line-height: 20px;
                    letter-spacing: 2px;
                    box-shadow: 0 0 1px 1px #000;
                    text-transform: uppercase;" onmouseover="this.style.backgroundColor='#A2a2a2';"
                                onmouseout="this.style.backgroundColor='#Ff6d00';">Sign In</a>
                        </li>
                        <li class="nav-item">
                            <a href="<?php echo e(route('Sign_Up')); ?>" class="button-primary rounded" style="padding: 12px 25px;
                    border: 1px solid #000;
                    background-color: #Ff6d00;
                    transition: all 200ms ease;
                    color: #000;
                    font-size: 15px;
                    line-height: 20px;
                    letter-spacing: 2px;
                    box-shadow: 0 0 1px 1px #000;
                    text-transform: uppercase;" onmouseover="this.style.backgroundColor='#A2a2a2';"
                                onmouseout="this.style.backgroundColor='#Ff6d00';">Sign Up</a>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>
    </section>

    <section id="welcome Message">
        <div class="bodyContainer text-center"
            style="background-color: #000000; padding-bottom: 50px; padding-top: 100px; border-bottom: 1px solid #Ff6d00;">
            <img src="<?php echo e(asset('assets/Images/SmartThink_Logo.png')); ?>" class="rounded mx-auto d-block" alt="SmartThink_Logo">
            <h1 class="mt-5" style="color: #Ffffff;">Welcome!</h1>
            <p class="mt-5" style="color: #Ffffff;">SmartTrack is an adaptive inventory solution to locating pesky items
                and improving your awareness of what
                you've got!</p>
        </div>
    </section>

    <section id="About Us" class="about-us d-flex justify-content-center">
        <div class="container-fluid d-flex flex-column justify-content-center" style="padding-top: 50px; background-color: #000000; padding-bottom: 50px;">
            <h2 id="About Us" class="centered-heading text-center" style="color: #FFFFFF;">ABOUT THE TEAM</h2>
            <p class="centered-subheading text-center" style="color: #FFFFFF; width: 500px; margin: 0 auto; padding-bottom: 50px;">Project: A
                new start-up nu-tracker-inventory-company pty has developed a system to track inventory through RFID
                tags and smart phones. The back end of their system is all cloud based; the phones used are all BYOD.
            </p>
            <div class="container justify-content-center">
                <div class="w-slider-mask d-flex justify-content-center">
                    <div class="justify-content-center" style="display: flex; width: 400px">
                        <div class="team-slide-wrapper w-slide justify-content-center" style="padding-right: 100px;">
                            <div class="team-block justify-content-center">
                                <img src="<?php echo e(asset('assets/Images/Ryan_Profile.jpg')); ?>" loading="lazy" width="283" alt="Andrew_Profile"
                                    class="team-member-image-two">
                                <div class="team-block-info">
                                    <h3 class="team-member-name-two" style="color: #FFFFFF;">Ryan Leach</h3>
                                    <p class="team-member-text" style="color: #FFFFFF;">Project Manager / Database
                                        Engineer & Front-End Developer.</p>
                                </div>
                            </div>
                        </div>
                        <div class="team-slide-wrapper w-slide justify-content-center">
                            <div class="team-block justify-content-center">
                                <img src="<?php echo e(asset('assets/Images/Andrew_Profile.jpg')); ?>" loading="lazy" width="283" alt="Andrew_Profile"
                                    class="team-member-image-two">
                                <div class="team-block-info">
                                    <h3 class="team-member-name-two" style="color: #FFFFFF;">Andrew Still</h3>
                                    <p class="team-member-text" style="color: #FFFFFF;">Architectural Designer / Lead
                                        Back-End Developer & Integrator.</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section class="footer" style="background-color: #Ff6d00;">
        <div class="container-2">
            <div class="footer-wrapper-2">
                <div class="footer-content-2 justify-content-center">
                    <div class="footer-block-2">
                        <div class="title-small-2">Company</div>
                        <a href="#" class="footer-link-2">How it works</a>
                        <a href="#" class="footer-link-2">Docs</a>
                    </div>
                    <div class="footer-block-2">
                        <div class="title-small-2">About</div>
                        <a href="#" class="footer-link-2">Terms &amp; Conditions</a>
                        <a href="#" class="footer-link-2">Privacy policy</a>
                    </div>
                </div>
            </div>
        </div>
        <div class="footer-divider-2"></div>
        <div class="footer-copyright-center-2">Copyright © 2023 Andrew Still || Ryan Leach</div>
    </section>
</body>
<?php /**PATH C:\laragon\www\SmartTrack - Reset\SmartTrack - Reset\resources\views/home.blade.php ENDPATH**/ ?>