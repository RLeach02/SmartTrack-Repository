<?php

?>

<!DOCTYPE html>
<html lang="english">

<head>
    <title>Dashboard</title>

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Latest compiled JavaScript -->
    <script src="<?php echo e(asset('js/Script.js')); ?>"></script>

    <!--  CSS -->
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <meta charset="utf-8" />

    <link rel="stylesheet"
        href="https://fonts.googleapis.com/css2?family=Inter:wght@100;200;300;400;500;600;700;800;900&amp;display=swap"
        data-tag="font" />

    <link rel="stylesheet" href="<?php echo e(asset('css/stylesheet.css')); ?>">

</head>

<body>
    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg sticky-top" style="background-color: #f5f7fa;">
        <div class="container-fluid">
            <a class="navbar-brand" href="<?php echo e(route('home')); ?>">
                <img src="<?php echo e(asset('assets/Images/Banner_Logo.png')); ?>" alt="BannerACTHALogo120" />
            </a>
            <h1 class="navbar-text d-none d-md-block col-sm-3"> ACT Health Archives</h1>

            <button class="navbar-toggler justify-content-end" type="button" data-bs-toggle="collapse"
                data-bs-target="#collapsibleNavbar">
                <span class="navbar-toggler-icon"></span>
            </button>

            <div class="collapse navbar-collapse" id="collapsibleNavbar">
                <ul class="navbar-nav justify-content-end">
                    <li>
                        <a id="Home" href="<?php echo e(route('home')); ?>#home" class="nav-link ">Home</a>
                    </li>
                    <li>
                        <a id="About-Us" href="<?php echo e(route('home')); ?>#About Us" class="nav-link">About Us</a>
                    </li>
                    <li>
                        <a id="Contacts" href="<?php echo e(route('home')); ?>#Contact Us" class="nav-link">Contact Us</a>
                    </li>
                    <li>
                        <div class="nav-divider"></div>
                    </li>
                    <li class="mobile-margin-top-10">
                        <a href="<?php echo e(route('home')); ?>" class="button-primary rounded">Log Out</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>
    <!-- Page banner -->
    <section class="content">
        <div class="col-sm-12 p-5 bg-primary text-white mx-auto">
            <h1 class="display-3">Welcome <?php echo e(session('first_name')); ?></h1>
            <h1 class="display-6">Select a folder below.</h1>
        </div>
        <!-- Div to hold the dashboard  -->
        <div class="row p-5 m-5"
            style="background-color: rgb(207, 233, 225);box-shadow: 0 0 5px 5px rgba(0, 0, 0, .2);">
            <!--Splitting dashboard in half -->
            <div class="col-sm-6 mb-3">
                <!-- Button/Link to personal details page -->
                <a href="<?php echo e(route('details', session('user_id'))); ?>" class="btn btn-lg btn-primary col-sm-12">
                    <img src="<?php echo e(asset('assets/Images/Icon_Profile.png')); ?>"
                        style="max-width: 100px; max-height: 100px;">
                    My Info </a>
            </div>
            <div class="col-sm-6">
                <!-- Button/Link to records page -->
                <a href="<?php echo e(route('records', ['id' => session('user_id')])); ?>"
                    class="btn btn-lg btn-primary col-sm-12">
                    <img src="<?php echo e(asset('assets/Images/Icon_Folder.png')); ?>" style="max-width: 100px; max-height:px;">
                    My Documents </a>
            </div>
        </div>
    </section>
</body>
<!-- Footer with links -->
<footer>
    <section class="footer wf-section">
        <div class="container-2">
            <div class="footer-wrapper-2">
                <a href="#" class="footer-brand-2 w-inline-block"><img
                        src="<?php echo e(asset('assets\Images\Banner_Logo.png')); ?>" loading="lazy" width="227"
                        sizes="(max-width: 479px) 88vw, 227px" alt=""></a>
                <div class="footer-content-2">
                    <div id="w-node-e88afaff-ea91-c9c2-0b63-22244fe33b01-e4e7dfff" class="footer-block-2">
                        <div class="title-small-2">Company</div>
                        <a href="#" class="footer-link-2">How it works</a>
                        <a href="#" class="footer-link-2">Docs</a>
                    </div>
                    <div id="w-node-e88afaff-ea91-c9c2-0b63-22244fe33b15-e4e7dfff" class="footer-block-2">
                        <div class="title-small-2">About</div>
                        <a href="#" class="footer-link-2">Terms &amp; Conditions</a>
                        <a href="#" class="footer-link-2">Privacy policy</a>
                    </div>
                </div>
            </div>
        </div>
        <div class="footer-divider-2"></div>
        <div class="footer-copyright-center-2">Copyright © 2023 Don Le || Tristan Kelly || Ryan Leach</div>
    </section>
</footer>

</html>
<?php /**PATH C:\laragon\www\MedicalRecordingSystem-reset\MedicalRecordingSystem-reset\resources\views/patient-dashboard.blade.php ENDPATH**/ ?>