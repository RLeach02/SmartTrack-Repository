<?php
Auth::logout();
?>
<!DOCTYPE html>
<html lang="english">

<head>
    <title>Login</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Latest compiled JavaScript -->
    <!-- <script src="../js/Script.js"></script> -->
    <script src="<?php echo e(asset('js/script.js')); ?>"></script>


    <link rel="stylesheet" href="<?php echo e(asset('css/stylesheet.css')); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <meta charset="utf-8" />
    <!-- <link rel="stylesheet" href="../CSS/login.css" /> -->
    <link rel="stylesheet" href="<?php echo e(asset('css/login.css')); ?>" />
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
</head>

<body>
    <!--Header - Navbar-->
    <nav class="navbar navbar-expand-lg fixed-top" style="background-color: #f5f7fa;">
        <div class="container-fluid">
            <a class="navbar-brand" href="<?php echo e(route('home')); ?>">
                <img src="<?php echo e(asset('assets/Images/Banner_Logo.png')); ?>" alt="BannerACTHALogo120" />
            </a>
            <h1 class="navbar-text d-none d-md-block col-sm-3"> ACT Health Archives</h1>


            <button class="navbar-toggler justify-content-end" type="button" data-bs-toggle="collapse"
                data-bs-target="#collapsibleNavbar">
                <span class="navbar-toggler-icon"></span>
            </button>

            <div class="collapse navbar-collapse" id="collapsibleNavbar">
                <ul class="navbar-nav justify-content-end">
                    <li>
                        <a id="Home" href="<?php echo e(route('home')); ?>#home" class="nav-link ">Home</a>
                    </li>
                    <li>
                        <a id="About-Us" href="<?php echo e(route('home')); ?>#About Us" class="nav-link">About Us</a>
                        <!-- <a id="About-Us" href="home.html#About Us" class="nav-link">About Us</a> -->
                    </li>
                    <li>
                        <a id="Contacts" href="<?php echo e(route('home')); ?>#Contact Us" class="nav-link">Contact Us</a>
                    </li>
                    <li>
                        <div class="nav-divider"></div>
                    </li>
                    <li class="mobile-margin-top-10">
                        <a href="<?php echo e(route('login')); ?>" class="button-primary rounded">Login / Register</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <!-- Log in Div -->
    <section class="container">
        <div class="container">
            <!-- Page banner -->
            <div class="col-sm-12 p-5 bg-primary text-white  mx-auto">
                <h1 class="display-3">Login</h1>
                <h1 class="display-6">Login and secure your records.</h1>
            </div>
        </div>
        <!-- Log in Div -->
        <!-- Create row div with padding-->
        <div class="row p-5" style="background-color: #f5f7fa;">
            <!-- Create column div to hold login form-->
            <div class="col-sm-4 p-5 rounded m-5 justify-content-center mx-auto"
                style="background-color: rgb(207, 233, 225);">
                <form class="was-validated" action="<?php echo e(route('login-form')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="col-sm-8 mb-3 mt-3">
                        <label for="email" class="form-label">Email:</label>
                        <input type="email" class="form-control" id="email" placeholder="Enter email"
                            name="email" required>
                        <div id="emailError" class="invalid-feedback">Please enter a valid email address.</div>
                    </div>
                    <div class="col-sm-8 mb-3">
                        <label for="pwd" class="form-label">Password:</label>
                        <input type="password" class="form-control" id="pwd" placeholder="Enter password"
                            name="pswd" required>
                        <div id="passwordFeedback" class="invalid-feedback">Please enter your password.</div>
                    </div>
                    <button onclick="login(event)" id="loginBtn" class="btn btn-success" type="submit">Submit</button>
                </form>
                <hr>
                <!-- Button link to Register page -->
                <div class="col-sm-12 mx-auto">
                    <a href="<?php echo e(route('register')); ?>">
                        <button type="button" class="btn btn-primary btn-sm">
                            <p>I need an account</p>
                        </button>
                    </a>

                    <!-- WE GOTTA GET THIS BIT WORKING
                    styling is already in login.css -->
                    <a href="open-popup">
                        <button type="button" class="btn btn-primary btn-sm">
                            <p>Recover Password</p>
                        </button>
                        <script>
                            document.querySelector("#open-popup").addEventListener("click", function() {
                                document.body.classList.add("active-popup")
                            });

                            document.querySelector(".popup .close-btn").addEventListener("click", function() {
                                document.body.classList.remove("active-popup")
                            });
                        </script>
                    </a>

                    <div class="popup">
                        <button class="close-btn">&times;</button>
                        <h2>Recover Password</h2>
                        <p>Lorem ipsum dolor sit amet consectetur, adipisicing elit. Minus repudiandae reprehenderit
                            quas provident
                            quis cupiditate. Est aliquid fugiat ea inventore maiores! Odio, explicabo. Corrupti omnis
                            vero quas fuga
                            sed suscipit.</p>
                    </div>
                </div>
            </div>
            <!-- Setting right half of div to be image/logo -->
            <div class="col-sm-6">
                <img class="img-fluid" src="<?php echo e(asset('assets/Images/Background_Logo.png')); ?>" alt="Logo" />
            </div>
        </div>
    </section>



    <!--Footer - Social Bar-->
    <section class="footer wf-section">
        <div class="container-2">
            <div class="footer-wrapper-2">
                <a class="footer-brand-2 w-inline-block"><img src="<?php echo e(asset('assets/Images/Banner_Logo.png')); ?>"
                        loading="lazy" width="227" sizes="(max-width: 479px) 88vw, 227px" alt=""></a>
                <div class="footer-content-2">
                    <div id="w-node-e88afaff-ea91-c9c2-0b63-22244fe33b01-e4e7dfff" class="footer-block-2">
                        <div class="title-small-2">Company</div>
                        <a href="#" class="footer-link-2">How it works</a>
                        <a href="#" class="footer-link-2">Docs</a>
                    </div>
                    <div id="w-node-e88afaff-ea91-c9c2-0b63-22244fe33b15-e4e7dfff" class="footer-block-2">
                        <div class="title-small-2">About</div>
                        <a href="#" class="footer-link-2">Terms &amp; Conditions</a>
                        <a href="#" class="footer-link-2">Privacy policy</a>
                    </div>
                </div>
            </div>
        </div>
        <div class="footer-divider-2"></div>
        <div class="footer-copyright-center-2">Copyright © 2023 Don Le || Tristan Kelly || Ryan Leach</div>
    </section>



</body>

</html>
<?php /**PATH C:\laragon\www\MedicalRecordingSystem-reset\MedicalRecordingSystem-reset\resources\views/login.blade.php ENDPATH**/ ?>