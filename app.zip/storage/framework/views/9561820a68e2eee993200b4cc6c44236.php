<?php
    Auth::logout();
?>
<!DOCTYPE html>
<html lang="english">

<head>
    <title>Home</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Latest compiled JavaScript -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>

    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <meta charset="utf-8" />
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Inter:wght@100;200;300;400;500;600;700;800;900&amp;display=swap" data-tag="font" />
    <link rel="stylesheet" href="<?php echo e(asset('css/stylesheet.css')); ?>" />

</head>

<body class="body">

    <nav class="navbar navbar-expand-lg fixed-top" style="background-color: #f5f7fa;">
        <div class="container-fluid">
            <a class="navbar-brand" href="<?php echo e(route('home')); ?>">

                <img src="<?php echo e(asset('assets/Images/Banner_Logo.png')); ?>" alt="BannerACTHALogo120" />
                <!-- <img src="assets/Images/Banner_Logo.png" alt="BannerACTHALogo120" /> -->
            </a>
            <h1 class="navbar-text d-none d-md-block col-sm-3"> ACT Health Archives</h1>


            <button class="navbar-toggler justify-content-end" type="button" data-bs-toggle="collapse" data-bs-target="#collapsibleNavbar">
                <span class="navbar-toggler-icon"></span>
            </button>

            <div class="collapse navbar-collapse" id="collapsibleNavbar">
                <ul class="navbar-nav justify-content-end">
                    <li>
                        <a id="Home" href="<?php echo e(route('home')); ?>#home" class="nav-link ">Home</a>
                    </li>
                    <li>
                        <a id="About-Us" href="<?php echo e(route('home')); ?>#About Us" class="nav-link">About Us</a>
                        <!-- <a id="About-Us" href="home.html#About Us" class="nav-link">About Us</a> -->
                    </li>
                    <li>
                        <a id="Contacts" href="<?php echo e(route('home')); ?>#Contact Us" class="nav-link">Contact Us</a>
                    </li>
                    <li>
                        <div class="nav-divider"></div>
                    </li>
                    <li class="mobile-margin-top-10">
                        <a href="<?php echo e(route('login')); ?>" class="button-primary rounded">Login / Register</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>




    <section id="home" class="home ">
        <div class="container-2">
            <h1 id="home" class="display-1 centered-heading margin-bottom-32px">ACT HEALTH ARCHIVES</h1>
            <div class="row">
                <div class="col-sm-6">
                    <p class="display-6 margin-bottom-50px">ACT on your health.</p>
                    <p class="display-6 margin-bottom-50px">Control your information.</p>
                    <p class="display-6 margin-bottom-50px">Trust your system.</p>
                </div>

                <div class="col-sm-6"><img src="<?php echo e(asset('assets/Images/Background_Logo.png')); ?>" class="img-fluid"></div>
                <!-- <div class="col-sm-6"><img src="assets/Images/Background_Logo.png" class="img-fluid"></div> -->
            </div>
        </div>

        </div>

    </section>
    <section id="About Us" class="about-us ">
        <div class="container-2">
            <h2 id="About Us" class="centered-heading">ABOUT THE TEAM</h2>
            <p class="centered-subheading">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Suspendisse tincidunt
                sagittis eros. Quisque quis euismod lorem.</p>
            <div class="w-slider-mask">
                <div style="display:flex">
                    <div class="team-slide-wrapper w-slide">
                        <div class="team-block"><img src="<?php echo e(asset('assets/Images/DocImg1.jpg')); ?>" loading="lazy" width="283" alt="" class="team-member-image-two">
                            <div class="team-block-info">
                                <h3 class="team-member-name-two">Ryan Leach</h3>
                                <p class="team-member-text">Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
                            </div>
                        </div>
                    </div>
                    <div class="team-slide-wrapper w-slide">
                        <div class="team-block"><img src="<?php echo e(asset('assets/Images/DocImg2.jpg')); ?>" loading="lazy" width="283" alt="" class="team-member-image-two">
                            <div class="team-block-info">
                                <h3 class="team-member-name-two">Tristan Kelly</h3>
                                <p class="team-member-text">Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
                            </div>
                        </div>
                    </div>
                    <div class="team-slide-wrapper w-slide">
                        <div class="team-block"><img src="<?php echo e(asset('assets/Images/DocImg3.jpg')); ?>" loading="lazy" width="283" alt="" class="team-member-image-two">
                            <div class="team-block-info">
                                <h3 class="team-member-name-two">Don Le</h3>
                                <p class="team-member-text">Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        </div>
    </section>

    <section id="Contact Us" class="contacts ">
        <div class="container-2">
            <h2 class="centered-heading">CONTACT A PROFESSIONAL</h2>
            <p class="centered-subheading">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Suspendisse tincidunt
                sagittis eros. Quisque quis euismod lorem.</p>
            <div class="team-grid">
                <div id="w-node-_3a5e9a68-bfad-c459-85c8-55750ae13a2e-e4e7dfff" class="team-card"><img src="https://uploads-ssl.webflow.com/62434fa732124a0fb112aab4/62434fa732124a55c612aae2_portfolio%202%20-%20wide.svg" loading="lazy" alt="" class="team-member-image">
                    <div class="team-member-name">Full Name</div>
                    <div class="team-member-position">Role at C<br>‍Previously: Company 1, Company 2</div>
                    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
                </div>
                <div id="w-node-_3a5e9a68-bfad-c459-85c8-55750ae13a39-e4e7dfff" class="team-card"><img src="https://uploads-ssl.webflow.com/62434fa732124a0fb112aab4/62434fa732124a55c612aae2_portfolio%202%20-%20wide.svg" loading="lazy" alt="" class="team-member-image">
                    <div class="team-member-name">Full Name</div>
                    <div class="team-member-position">Role at Company<br>Previously: Company 1, Company 2</div>
                    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
                </div>
                <div id="w-node-_3a5e9a68-bfad-c459-85c8-55750ae13a43-e4e7dfff" class="team-card"><img src="https://uploads-ssl.webflow.com/62434fa732124a0fb112aab4/62434fa732124a55c612aae2_portfolio%202%20-%20wide.svg" loading="lazy" alt="" class="team-member-image">
                    <div class="team-member-name">Full Name</div>
                    <div class="team-member-position">Role at Company<br>Previously: Company 1, Company 2</div>
                    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
                </div>
                <div id="w-node-_3a5e9a68-bfad-c459-85c8-55750ae13a4d-e4e7dfff" class="team-card"><img src="https://uploads-ssl.webflow.com/62434fa732124a0fb112aab4/62434fa732124a55c612aae2_portfolio%202%20-%20wide.svg" loading="lazy" alt="" class="team-member-image">
                    <div class="team-member-name">Full Name</div>
                    <div class="team-member-position">Role at Company<br>Previously: Company 1, Company 2</div>
                    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
                </div>
                <div id="w-node-_3a5e9a68-bfad-c459-85c8-55750ae13a57-e4e7dfff" class="team-card"><img src="https://uploads-ssl.webflow.com/62434fa732124a0fb112aab4/62434fa732124a55c612aae2_portfolio%202%20-%20wide.svg" loading="lazy" alt="" class="team-member-image">
                    <div class="team-member-name">Full Name</div>
                    <div class="team-member-position">Role at Company<br>Previously: Company 1, Company 2</div>
                    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
                </div>
                <div id="w-node-_3a5e9a68-bfad-c459-85c8-55750ae13a61-e4e7dfff" class="team-card"><img src="https://uploads-ssl.webflow.com/62434fa732124a0fb112aab4/62434fa732124a55c612aae2_portfolio%202%20-%20wide.svg" loading="lazy" alt="" class="team-member-image">
                    <div class="team-member-name">Full Name</div>
                    <div class="team-member-position">Role at Company<br>Previously: Company 1, Company 2</div>
                    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
                </div>
            </div>
        </div>
    </section>
</body>

<footer>
    <section class="footer">
        <div class="container-2">
            <div class="footer-wrapper-2">
                <a href="#" class="footer-brand-2 w-inline-block"><img src="<?php echo e(asset('assets/Images/Banner_Logo.png')); ?>" loading="lazy" width="227" sizes="(max-width: 479px) 88vw, 227px" alt=""></a>
                <div class="footer-content-2">
                    <div id="w-node-e88afaff-ea91-c9c2-0b63-22244fe33b01-e4e7dfff" class="footer-block-2">
                        <div class="title-small-2">Company</div>
                        <a href="#" class="footer-link-2">How it works</a>
                        <a href="#" class="footer-link-2">Docs</a>
                    </div>
                    <div id="w-node-e88afaff-ea91-c9c2-0b63-22244fe33b15-e4e7dfff" class="footer-block-2">
                        <div class="title-small-2">About</div>
                        <a href="#" class="footer-link-2">Terms &amp; Conditions</a>
                        <a href="#" class="footer-link-2">Privacy policy</a>
                    </div>
                </div>
            </div>
        </div>
        <div class="footer-divider-2"></div>
        <div class="footer-copyright-center-2">Copyright © 2023 Don Le || Tristan Kelly || Ryan Leach</div>
    </section>
</footer>

</html>
<?php /**PATH C:\laragon\www\MedicalRecordingSystem-reset\MedicalRecordingSystem-reset\resources\views/home.blade.php ENDPATH**/ ?>