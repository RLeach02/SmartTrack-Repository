<?php
$user = auth()->user();
?>
<!DOCTYPE html>
<html lang="english">

<head>
    <title>My Info </title>

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Latest compiled JavaScript -->
    <script src="<?php echo e(asset('js/Script.js')); ?>"></script>

    <!--  CSS -->
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <meta charset="utf-8" />

    <link rel="stylesheet"
        href="https://fonts.googleapis.com/css2?family=Inter:wght@100;200;300;400;500;600;700;800;900&amp;display=swap"
        data-tag="font" />

    <link rel="stylesheet" href="<?php echo e(asset('css/register.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('css/stylesheet.css')); ?>">

</head>

<body>
    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg fixed-top" style="background-color: #f5f7fa;">
        <div class="container-fluid">
            <a class="navbar-brand" href="<?php echo e(route('home')); ?>">
                <img src="<?php echo e(asset('assets/Images/Banner_Logo.png')); ?>" alt="BannerACTHALogo120" />
            </a>
            <h1 class="navbar-text d-none d-md-block col-sm-3"> ACT Health Archives</h1>

            <button class="navbar-toggler justify-content-end" type="button" data-bs-toggle="collapse"
                data-bs-target="#collapsibleNavbar">
                <span class="navbar-toggler-icon"></span>
            </button>

            <div class="collapse navbar-collapse" id="collapsibleNavbar">
                <ul class="navbar-nav justify-content-end">
                    <li>
                        <a id="Home" href="<?php echo e(route('home')); ?>#home" class="nav-link ">Home</a>
                    </li>
                    <li>
                        <a id="About-Us" href="<?php echo e(route('home')); ?>#About Us" class="nav-link">About Us</a>
                    </li>
                    <li>
                        <a id="Contacts" href="<?php echo e(route('home')); ?>#Contact Us" class="nav-link">Contact Us</a>
                    </li>
                    <li>
                        <a id="Dashboard" href="<?php echo e(route('dashboard')); ?>" class="nav-link">Dashboard</a>
                    </li>
                    <li>
                        <div class="nav-divider"></div>
                    </li>
                    <li class="mobile-margin-top-10">
                        <a href="<?php echo e(route('home')); ?>" class="button-primary rounded">Log Out</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <section class="content">
        <div class="col-sm-12 p-5 bg-primary text-white  mx-auto">
            <h1 class="display-5">My Info</h1>
        </div>
        <div class="col-sm-12 p-1 bg-primary text-white background-color:aquamarine mx-auto">
            <a href="<?php echo e(route('dashboard')); ?>">
                <button type="button" class="btn btn-success">Back to Dashboard</button>
            </a>
        </div>
    </section>

    <section class="Control">
        <div class="row p-5" style="background-color: #c8dbd6">
            <div class="col-sm-6">
                <!-- All values are set to readonly, to prevent accidental changes -->
                <form>
                    <!-- Button link to editable version of page -->
                    <a href="<?php echo e(route('edit', $user->id)); ?>" class="btn btn-primary col-sm-3">Edit Details</a>
                    <div class="form-group col-sm-7">
                        <label class="form-label" for="givenName">First Name / Middle Name(s):</label>
                        <input type="text" class="form-control" id="givenName" name="givenName" readonly
                            value="<?php echo e($user->first_name); ?>">
                    </div>
                    <div class="form-group col-sm-7">
                        <label class="form-label" for="surname">Surname:</label>
                        <input type="text" class="form-control" id="surname" name="surname" readonly
                            value="<?php echo e($user->last_name); ?>">
                    </div>
                    <div class="form-group col-sm-4">
                        <label class="form-label" for="dob">Date of Birth:</label>
                        <input type="date" class="form-control" id="dob" name="dob" readonly
                            value="<?php echo e($user->DOB); ?>">
                    </div>
                    <div class="form-group col-sm-5">
                        <label class="form-label" for="gender">Gender:</label>
                        <!-- <select class="form-control " id="gender" name="gender" readonly value="<?php echo e($user->gender); ?>"> -->
                        <select class="form-control" id="gender" name="gender">
                            <option value="male" <?php if($user->gender === 'Male'): ?> selected <?php endif; ?>>Male</option>
                            <option value="female" <?php if($user->gender === 'Female'): ?> selected <?php endif; ?>>Female</option>
                            <option value="other" <?php if($user->gender === 'Other'): ?> selected <?php endif; ?>>Other</option>
                        </select>
                    </div>

                    <div class="form-group col-sm-7">
                        <label class="form-label" for="email">Email:</label>
                        <input type="email" class="form-control" id="email" name="email" readonly
                            value="<?php echo e($user->email); ?>">
                    </div>

                    <div class="form-group col-sm-7">
                        <label class="form-label" for="phone_number">Phone Number:</label>
                        <?php if(isset($phoneContact)): ?>
                            <input type="tel" class="form-control" id="phone_number" name="phone_number"
                                readonly value=" <?php echo e($phoneContact['phone_number']); ?>">
                        <?php else: ?>
                            <input type="tel" class="form-control" id="phone_number" name="phone_number"
                                readonly value="N/A">
                        <?php endif; ?>
                    </div>


                    <div class="form-group col-sm-7">
                        <label class="form-label" for="dependents">Dependents:</label>
                        <textarea class="form-control" id="dependents" name="dependents" rows="4" readonly>Joe Bloggs Citizen 0497532785</textarea>
                    </div>
                </form>
            </div>
            <!-- Logo next to form -->
            <div class="col-sm-6 container-fluid justify-content-center">
                <img class="img-fluid" src="<?php echo e(asset('assets/Images/Background_Logo.png')); ?>"
                    alt="BackgroundACTHALogo1266" />
            </div>
        </div>
    </section>
</body>

<footer>
    <section class="footer wf-section">
        <div class="container-2">
            <div class="footer-wrapper-2">
                <a href="#" class="footer-brand-2 w-inline-block"><img
                        src="<?php echo e(asset('assets/Images/Banner_Logo.png')); ?>" loading="lazy" width="227"
                        sizes="(max-width: 479px) 88vw, 227px" alt="Footer Logo"></a>
                <div class="footer-content-2">
                    <div id="w-node-e88afaff-ea91-c9c2-0b63-22244fe33b01-e4e7dfff" class="footer-block-2">
                        <div class="title-small-2">Company</div>
                        <a href="#" class="footer-link-2">How it works</a>
                        <a href="#" class="footer-link-2">Docs</a>
                    </div>
                    <div id="w-node-e88afaff-ea91-c9c2-0b63-22244fe33b15-e4e7dfff" class="footer-block-2">
                        <div class="title-small-2">About</div>
                        <a href="#" class="footer-link-2">Terms &amp; Conditions</a>
                        <a href="#" class="footer-link-2">Privacy policy</a>
                    </div>
                </div>
            </div>
        </div>
        <div class="footer-divider-2"></div>
        <div class="footer-copyright-center-2">Copyright © 2023 Don Le || Tristan Kelly || Ryan Leach</div>
    </section>
</footer>


</html>
<?php /**PATH C:\laragon\www\MedicalRecordingSystem-reset\MedicalRecordingSystem-reset\resources\views/personal-details.blade.php ENDPATH**/ ?>