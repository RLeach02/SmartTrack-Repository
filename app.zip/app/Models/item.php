<?php

namespace App\Models;

use Illuminate\Contracts\Auth\Authenticatable;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class item extends Model implements Authenticatable
{
    protected $primaryKey = 'RFID';
    protected $keyType = 'string'; // Assuming RFID is a string
    public $incrementing = false; // Assuming the primary key is not auto-incrementing

    protected $fillable = [
        'RFID',
        'Location',
        'ProductID',
        'ProductName',
        'Supplier',
    ];

    public function getAuthIdentifier()
    {
        return $this->employeeID;
    }
    public function getAuthIdentifierName()
    {
        return 'employeeID';
    }
    public function getAuthPassword()
    {
        return $this->passwords->password_hash;
    }
    public function getRememberToken()
    {
        return null;
    }

    public function setRememberToken($value)
    {
        // return null;
    }
    public function getRememberTokenName()
    {
        // return null;
    }
}
