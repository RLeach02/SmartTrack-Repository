<?php

namespace App\Models;

use Illuminate\Contracts\Auth\Authenticatable;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class inventory extends Model implements Authenticatable
{
    protected $primaryKey = 'ProductID';
    protected $keyType = 'string'; // Assuming ProductID is a string
    public $incrementing = false; // Assuming the primary key is not auto-incrementing

    protected $fillable = [
        'ProductID',
        'Location',
        'ProductName',
        'Stock',
    ];

    public function getAuthIdentifier()
    {
        return $this->employeeID;
    }
    public function getAuthIdentifierName()
    {
        return 'employeeID';
    }
    public function getAuthPassword()
    {
        return $this->passwords->password_hash;
    }
    public function getRememberToken()
    {
        return null;
    }

    public function setRememberToken($value)
    {
        // return null;
    }
    public function getRememberTokenName()
    {
        // return null;
    }
}
