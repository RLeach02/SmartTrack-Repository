<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class passwords extends Model
{
    use HasFactory;
    public $timestamps = false;

    protected $primaryKey = 'employeeID';

    protected $fillable = ['employeeID', 'password_hash'];

    public function user()
    {
        return $this->belongsTo(User::class, 'employeeID');
    }
}
