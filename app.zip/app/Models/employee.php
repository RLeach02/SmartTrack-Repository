<?php

namespace App\Models;

use Illuminate\Contracts\Auth\Authenticatable;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class employee extends Model implements Authenticatable
{
    use HasFactory;
    public $timestamps = false;

    protected $fillable = ['employeeID', 'password_hash', 'role'];

    public function passwords()
    {
        return $this->hasOne(Password::class);
    }

    public function getAuthIdentifier()
    {
        return $this->employeeID;
    }
    public function getAuthIdentifierName()
    {
        return 'employeeID';
    }
    public function getAuthPassword()
    {
        return $this->passwords->password_hash;
    }
    public function getRememberToken()
    {
        return null;
    }

    public function setRememberToken($value)
    {
        // return null;
    }
    public function getRememberTokenName()
    {
        // return null;
    }
}
