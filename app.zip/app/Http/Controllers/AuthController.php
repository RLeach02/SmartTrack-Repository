<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\employee;
use App\Models\passwords;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Auth;



class AuthController extends Controller
{
    //

    public function login(Request $request)
    {
        try {
            $credentials = $request->validate([
                'employeeID' => 'required|employeeID',
                'password' => 'required',
            ]);

            // Retrieve the user by employeeID
            $user = employee::where('employeeID', $credentials['employeeID'])->first();

            if (!$user) {
                \Illuminate\Support\Facades\Log::debug('User not found');
                return response()->json(['message' => 'Invalid credentials'], 401);
            }

            // Retrieve the user's password
            $password = employee::where('employeeID', $user->employeeID)->first();

            if (!$password || !Hash::check($credentials['password'], $password->password_hash)) {
                \Illuminate\Support\Facades\Log::debug('Password not found');
                return response()->json(['success' => false, 'message' => 'Invalid credentials'], 401);
            }

            // Authentication successful
            // You can perform additional actions here, such as generating tokens or setting session data
            Log::debug('Credentials Valid');
            session(['employeeID' => $user->employeeID]);
            Auth::login($user);
            return response()->json(['success' => true, 'message' => 'Login successful']);
        } catch (\Illuminate\Validation\ValidationException $e) {
            \Illuminate\Support\Facades\Log::error('Validation error: ' . $e->getMessage());
            return response()->json(['success' => false, 'message' => 'Validation error'], 422);
        } catch (\Exception $e) {
            \Illuminate\Support\Facades\Log::error('Error: ' . $e->getMessage());
            return response()->json(['success' => false, 'message' => 'An error occurred'], 500);
        }
    }
}
