<?php

namespace App\Http\Controllers;

use App\Models\employee;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class UsersController extends Controller
{
    // /**
    //  * Display a listing of the resource.
    //  */
    // public function index($view)
    // {
    //     // return Users::all();
    //     return view($view, ['users' => Users::all()]);
    // }

    public function index($view)
    {
        $users = employee::all();
        return $users;
        // return view($view, compact('users'));
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        return employee::create($request->all());
        //
    }

    /**
     * Display the specified resource.
     */
    public function show(int $employee, $view)
    {
        // return Users::find($id);
        $user = Users::find($employee);
        return view($view, compact('user'));

        //
    }

    /**
     * Display the specified resource.
     */
    public function find(Request $request)
    {
        $name = $request->query('RFID-Code');
        $result = DB::table('employees')->where('RFID-Code', $name)->get();
        return $result;
        //
    }
}
