<?php

namespace App\Http\Controllers;

use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Http\Request;
use App\Models\employee;
use App\Models\passwords;
use App\Models\item;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Session;
use \Illuminate\Support\Facades\Log;

class UserController extends Controller
{
    // User login
    public function login(Request $request)
    {
        // validates if the user is logged in
        $employeeID = $request->input('employeeID');
        $password = $request->input('password');

        $user = employees::where('employeeID', $employeeID)->first();

        if ($user && Hash::check($password, $user->password)) {
            // checks the passwords match with the session data
            $request->session()->put('user', $user);
            return redirect('Scan_RFID');
        } else {
            // If authentication is failed it redirects
            return back()->withErrors([
                'employeeID' => 'The provided credentials do not match our records.',
            ]);
        }
    }

    // User logout
    public function logout(Request $request)
    {
        Log::info('Logout function called.'); // Add this line
        //deletes session data for current user on logout
        $request->session()->forget('user');
        return redirect('home');
    }



    // Retrieve user details
    public function getUserDetails(int $employeeID)
    {
        if (!Auth::check()) {
            return redirect()->route('Sign_In');
        }
        $user = employees::find($employeeID);

        Log::debug('Out: ' . json_encode($user));
        return compact('user');
    }

    // ! methods that return views
    public function showMyInfo(Request $request, $employeeID)
    {
        //validates a session has started
        if (!$request->session()->has('user')) {
            Log::debug('Session does not have user. Redirecting to login');
            return redirect('Sign_In');
        }
        //retreives user session data
        $employeeID = $request->session()->get('user')->employeeID;
        Log::debug('User employeeID from session: ' . $employeeID);


        $user = Users::find($employeeID);
        if (!$user) {
            return redirect()->route('home')->with('error', 'User not found.');
        }
        $userDetails = $this->getUserDetails($employeeID);

        return view('Product', $userDetails);
    }

    public function register(Request $request)
    {
        \Illuminate\Support\Facades\Log::debug('Point 1');

        try {
            //Log request data
            \Illuminate\Support\Facades\Log::debug('Request: ' . $request);


            $validatedData = $request->validate([
                'employeeID' => 'required|unique:employees|digits:10',
                'password' => 'required|min:6',
            ]);
            \Illuminate\Support\Facades\Log::debug('Point 2');

            $user = new employee();
            $user->employeeID = $validatedData['employeeID'];
            $user->password_hash = bcrypt($validatedData['password']);
            // Set other password properties as needed

            $user->save();
            \Illuminate\Support\Facades\Log::debug('Point 3');
            return response()->json(['success' => true, 'message' => 'Registration successful']);
        } catch (\Illuminate\Validation\ValidationException $e) {
            //Log error
            \Illuminate\Support\Facades\Log::debug('Error: ' . $e);
            return response()->json(['success' => false, 'errors' => $e->errors()], 422);
        } catch (\Exception $e) {
            \Illuminate\Support\Facades\Log::debug('Error: ' . $e);
            return response()->json(['success' => false, 'message' => 'Registration failed'], 500);
        } catch (\Exception $e) {
            \Illuminate\Support\Facades\Log::debug('Error: ' . $e->getMessage());
            \Illuminate\Support\Facades\Log::debug('Stack Trace: ' . $e->getTraceAsString());
            return response()->json(['success' => false, 'message' => 'Registration failed'], 500);
        }
    }

    public function product(Request $request)
    {
        // Retrieve the user details from the session or fetch them from the database
        $userDetails = $request->session()->get('userDetails');

        // Retrieve the RFID code from the session
        $rfidCode = $request->session()->get('RFIDCode');

        //Retrieve all items from the item table in database
        $items = item::where('RFID', $rfidCode)->get();

        // Pass the user details and RFID code to the view
        return view('Product', compact('userDetails', 'items', 'rfidCode'));
    }

    public function scan(Request $request)
    {
        try {

            $validatedData = $request->validate([
                'RFIDCode' => 'required|digits_between:1,24',
            ]);

            $rfidCode = $validatedData['RFIDCode'];

            // Perform a database query to check if the RFID code exists in the item table
            $itemExists = item::where('RFID', $rfidCode)->exists();

            if ($itemExists) {
                //Store RFIDCode in session information
                $request->session()->put('RFIDCode', $rfidCode);

                //Retrieve all items from the item table in database
                $items = item::all();

                // RFID code exists in the item table
                return response()->json(['success' => true, 'message' => 'RFID code exists in the item table']);

                //Redirect to the Product view
                return view('Product', compact('items', 'rfidCode'));
            } else {
                // RFID code does not exist in the item table
                return response()->json(['success' => false, 'message' => 'RFID code does not exist in the item table'], 401);
            }
        } catch (\Illuminate\Validation\ValidationException $e) {
            \Illuminate\Support\Facades\Log::error('Validation error: ' . $e->getMessage());
            return response()->json(['success' => false, 'message' => 'Validation error'], 422);
        } catch (\Exception $e) {
            \Illuminate\Support\Facades\Log::error('Error: ' . $e->getMessage());
            return response()->json(['success' => false, 'message' => 'An error occurred'], 500);
        }
    }

}
